Requests for PHP
================

**Requests** is a HTTP library written in PHP, for human beings. It is roughly
based on the API from the excellent [Requests Python
library](http://python-requests.org/). **Requests** is [ISC
Licensed](https://github.com/rmccue/Requests/blob/master/LICENSE) (similar to
the new BSD license) and has no dependencies, except for PHP 5.2+.

**Requests** can be found here : https://github.com/rmccue/Requests
