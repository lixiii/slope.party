# Voting

--------------------------------------------------------------------------

Allows users to vote for comments and discussions. Administrators get unlimited votes.

All credits go to Mark O'Sullivan. I'm only maitaining this plugin to work with current and future version of the Vanilla Forum.

--------------------------------------------------------------------------

####Plugin Page
http://vanillaforums.org/addon/voting-plugin